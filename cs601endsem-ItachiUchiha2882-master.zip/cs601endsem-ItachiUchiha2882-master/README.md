[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-9f69c29eadd1a2efcce9672406de9a39573de1bdf5953fef360cfc2c3f7d7205.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=9343764)
*This is an individual assignment. You must not discuss / share your solution with others.*

Due at: **8AM IST 16/11/2022**

Submission Instructions
*The submission instructions for turning in this exam is similar to what you have been following for homework/programming assignments.*
 
After you are done making edits to the files: 
1. You must save the changes by committing the files in your local repository (use `git add` and `git commit` commands for this.) 
2. You must push the saved changes to GitHub.com (use `git push` command for this)
3. You must tag the saved changes (use `git tag -a cs601endsemsubmission -m "Submitting exam"` command)
4. You must push the saved tags to GitHub.com (use `git push --tags` command)

