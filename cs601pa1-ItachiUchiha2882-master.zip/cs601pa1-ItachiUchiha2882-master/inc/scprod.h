#ifndef SCPROD_V4_H
#define SCPROD_V4_H
//#pragma once
namespace cs601{

double ddot(int dim, double vec1[], double vec2[]);

}

#endif